const getEmployees = require('./getEmployees.json');
const getEmployee = require('./getEmployee.json');

module.exports = {
  getEmployees: getEmployees,
  getEmployee: getEmployee
};
