const getDepartments = require('./getDepartments.json');


module.exports = {
  getDepartments: getDepartments
};
